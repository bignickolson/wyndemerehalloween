-- Compiled migration script for all tables 




------------------------------------------------
-- ROLLBACK FOR [config].[CaseItemDetail]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[CaseItemDetail]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[CaseItemDetail] DROP CONSTRAINT [PK_CaseItemDetail]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[CaseItemDetail] DROP CONSTRAINT [DF_CaseItemDetail_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[CaseItemDetail] DROP Column [Id]
EXEC sp_rename '[config].[CaseItemDetail].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[CaseItemDetail] ADD CONSTRAINT [PK_CaseItemDetail] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- ROLLBACK FOR [config].[ClaimDetail]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[ClaimDetail]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[ClaimDetail] DROP CONSTRAINT [PK_ClaimDetail]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[ClaimDetail] DROP CONSTRAINT [DF_ClaimDetail_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[ClaimDetail] DROP Column [Id]
EXEC sp_rename '[config].[ClaimDetail].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[ClaimDetail] ADD CONSTRAINT [PK_ClaimDetail] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- ROLLBACK FOR [config].[EntityDetail]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[EntityDetail]  ADD [tempId] int IDENTITY(1,1) not null 
ALTER TABLE  [config].[EntityDetailItem]  ADD [EntityDetailIdtempId] int
GO

-- drop constraints, foreign keys first then PK
ALTER TABLE [config].[EntityDetailItem] DROP CONSTRAINT [FK_EntityDetailItem_EntityDetail_EntityDetailId]

ALTER TABLE [config].[EntityDetail] DROP CONSTRAINT [PK_EntityDetail]


------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[EntityDetail]  and [config].[EntityDetailItem] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_EntityDetailItem_EntityDetailId] ON [config].[EntityDetailItem]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[EntityDetailIdtempId] = [source].[tempId]
FROM [config].[EntityDetailItem] [target] INNER JOIN [config].[EntityDetail] [source] ON [source].[Id] = [target].[EntityDetailId]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[EntityDetailItem] DROP Column [EntityDetailId]
EXEC sp_rename '[config].[EntityDetailItem].EntityDetailIdtempId', 'EntityDetailId', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [config].[EntityDetailItem] ALTER COLUMN [EntityDetailId] int NOT NULL

-- re-create indexes
CREATE INDEX [IX_EntityDetailItem_EntityDetailId] ON [config].[EntityDetailItem]([EntityDetailId])

-- uuid PK columns have a default constraint
ALTER TABLE [config].[EntityDetail] DROP CONSTRAINT [DF_EntityDetail_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[EntityDetail] DROP Column [Id]
EXEC sp_rename '[config].[EntityDetail].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[EntityDetail] ADD CONSTRAINT [PK_EntityDetail] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
ALTER TABLE [config].[EntityDetailItem] ADD CONSTRAINT [FK_EntityDetailItem_EntityDetail_EntityDetailId] FOREIGN KEY ([EntityDetailId]) REFERENCES [config].[EntityDetail]([Id])
ALTER TABLE [config].[EntityDetailItem] CHECK CONSTRAINT [FK_EntityDetailItem_EntityDetail_EntityDetailId];






------------------------------------------------
-- ROLLBACK FOR [config].[EntityDetailItem]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[EntityDetailItem]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[EntityDetailItem] DROP CONSTRAINT [PK_EntityDetailItem]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[EntityDetailItem] DROP CONSTRAINT [DF_EntityDetailItem_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[EntityDetailItem] DROP Column [Id]
EXEC sp_rename '[config].[EntityDetailItem].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[EntityDetailItem] ADD CONSTRAINT [PK_EntityDetailItem] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- ROLLBACK FOR [config].[FeatureFlag]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[FeatureFlag]  ADD [tempId] int IDENTITY(1,1) not null 
ALTER TABLE  [app_generated].[MenuItem]  ADD [FeatureFlagIdtempId] int
GO

-- drop constraints, foreign keys first then PK
ALTER TABLE [app_generated].[MenuItem] DROP CONSTRAINT [FK_MenuItem_FeatureFlag_FeatureFlagId]

ALTER TABLE [config].[FeatureFlag] DROP CONSTRAINT [PK_FeatureFlag]


------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[FeatureFlag]  and [app_generated].[MenuItem] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_MenuItem_FeatureFlagId] ON [app_generated].[MenuItem]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[FeatureFlagIdtempId] = [source].[tempId]
FROM [app_generated].[MenuItem] [target] INNER JOIN [config].[FeatureFlag] [source] ON [source].[Id] = [target].[FeatureFlagId]

-- Drop old foreign key column and rename new one
ALTER TABLE [app_generated].[MenuItem] DROP Column [FeatureFlagId]
EXEC sp_rename '[app_generated].[MenuItem].FeatureFlagIdtempId', 'FeatureFlagId', 'COLUMN';


-- re-create indexes
CREATE INDEX [IX_MenuItem_FeatureFlagId] ON [app_generated].[MenuItem]([FeatureFlagId])

-- uuid PK columns have a default constraint
ALTER TABLE [config].[FeatureFlag] DROP CONSTRAINT [DF_FeatureFlag_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[FeatureFlag] DROP Column [Id]
EXEC sp_rename '[config].[FeatureFlag].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[FeatureFlag] ADD CONSTRAINT [PK_FeatureFlag] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
ALTER TABLE [app_generated].[MenuItem] ADD CONSTRAINT [FK_MenuItem_FeatureFlag_FeatureFlagId] FOREIGN KEY ([FeatureFlagId]) REFERENCES [config].[FeatureFlag]([Id])
ALTER TABLE [app_generated].[MenuItem] CHECK CONSTRAINT [FK_MenuItem_FeatureFlag_FeatureFlagId];






------------------------------------------------
-- ROLLBACK FOR [config].[FEFilter]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[FEFilter]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[FEFilter] DROP CONSTRAINT [PK_FEFilter]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[FEFilter] DROP CONSTRAINT [DF_FEFilter_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[FEFilter] DROP Column [Id]
EXEC sp_rename '[config].[FEFilter].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[FEFilter] ADD CONSTRAINT [PK_FEFilter] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- ROLLBACK FOR [app_generated].[GeoNode]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [app_generated].[GeoNode]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [app_generated].[GeoNode] DROP CONSTRAINT [PK_GeoNode]
-- uuid PK columns have a default constraint
ALTER TABLE [app_generated].[GeoNode] DROP CONSTRAINT [DF_GeoNode_RowId_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [app_generated].[GeoNode] DROP Column [RowId]
EXEC sp_rename '[app_generated].[GeoNode].tempId', 'RowId', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [app_generated].[GeoNode] ADD CONSTRAINT [PK_GeoNode] PRIMARY KEY ([RowId]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- ROLLBACK FOR [config].[GeoSpatialIcon]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[GeoSpatialIcon]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[GeoSpatialIcon] DROP CONSTRAINT [PK_GeoSpatialIcon]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[GeoSpatialIcon] DROP CONSTRAINT [DF_GeoSpatialIcon_RowID_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[GeoSpatialIcon] DROP Column [RowID]
EXEC sp_rename '[config].[GeoSpatialIcon].tempId', 'RowID', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GeoSpatialIcon] ADD CONSTRAINT [PK_GeoSpatialIcon] PRIMARY KEY ([RowID]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- ROLLBACK FOR [config].[GridColumn]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[GridColumn]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[GridColumn] DROP CONSTRAINT [PK_GridColumn]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[GridColumn] DROP CONSTRAINT [DF_GridColumn_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[GridColumn] DROP Column [Id]
EXEC sp_rename '[config].[GridColumn].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GridColumn] ADD CONSTRAINT [PK_GridColumn] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- ROLLBACK FOR [config].[GridConfiguration]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[GridConfiguration]  ADD [tempId] int IDENTITY(1,1) not null 
ALTER TABLE  [config].[EntityDetail]  ADD [GridConfigurationIdtempId] int
ALTER TABLE  [config].[GeoSpatialMaps]  ADD [GridConfigurationIdtempId] int
ALTER TABLE  [config].[GridColumn]  ADD [GridConfigurationIdtempId] int
ALTER TABLE  [app_generated].[SearchCore]  ADD [GridConfigurationIdtempId] int
ALTER TABLE  [app_generated].[WatchlistConfiguration]  ADD [GridConfigurationIdtempId] int
ALTER TABLE  [app_generated].[WorkingFolderConfiguration]  ADD [GridConfigurationIdtempId] int
GO

-- drop constraints, foreign keys first then PK
ALTER TABLE [config].[EntityDetail] DROP CONSTRAINT [FK_EntityDetail_GridConfiguration_GridConfigurationId]
ALTER TABLE [config].[GeoSpatialMaps] DROP CONSTRAINT [FK_GeoSpatialMaps_GridConfiguration_GridConfigurationId]
ALTER TABLE [config].[GridColumn] DROP CONSTRAINT [FK_GridColumn_GridConfiguration_GridConfigurationId]
ALTER TABLE [app_generated].[SearchCore] DROP CONSTRAINT [FK_SearchCore_GridConfiguration_GridConfigurationId]
ALTER TABLE [app_generated].[WatchlistConfiguration] DROP CONSTRAINT [FK_WatchlistConfiguration_GridConfiguration_GridConfigurationId]
ALTER TABLE [app_generated].[WorkingFolderConfiguration] DROP CONSTRAINT [FK_WorkingFolderConfiguration_GridConfiguration_GridConfigurationId]

ALTER TABLE [config].[GridConfiguration] DROP CONSTRAINT [PK_GridConfiguration]


------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [config].[EntityDetail] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_EntityDetail_GridConfigurationId] ON [config].[EntityDetail]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIdtempId] = [source].[tempId]
FROM [config].[EntityDetail] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[EntityDetail] DROP Column [GridConfigurationId]
EXEC sp_rename '[config].[EntityDetail].GridConfigurationIdtempId', 'GridConfigurationId', 'COLUMN';


-- re-create indexes
CREATE INDEX [IX_EntityDetail_GridConfigurationId] ON [config].[EntityDetail]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [config].[GeoSpatialMaps] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_GeoSpatialMaps_GridConfigurationId] ON [config].[GeoSpatialMaps]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIdtempId] = [source].[tempId]
FROM [config].[GeoSpatialMaps] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[GeoSpatialMaps] DROP Column [GridConfigurationId]
EXEC sp_rename '[config].[GeoSpatialMaps].GridConfigurationIdtempId', 'GridConfigurationId', 'COLUMN';


-- re-create indexes
CREATE INDEX [IX_GeoSpatialMaps_GridConfigurationId] ON [config].[GeoSpatialMaps]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [config].[GridColumn] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_GridColumn_GridConfigurationId] ON [config].[GridColumn]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIdtempId] = [source].[tempId]
FROM [config].[GridColumn] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[GridColumn] DROP Column [GridConfigurationId]
EXEC sp_rename '[config].[GridColumn].GridConfigurationIdtempId', 'GridConfigurationId', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [config].[GridColumn] ALTER COLUMN [GridConfigurationId] int NOT NULL

-- re-create indexes
CREATE INDEX [IX_GridColumn_GridConfigurationId] ON [config].[GridColumn]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [app_generated].[SearchCore] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_SearchCore_GridConfigurationId] ON [app_generated].[SearchCore]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIdtempId] = [source].[tempId]
FROM [app_generated].[SearchCore] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [app_generated].[SearchCore] DROP Column [GridConfigurationId]
EXEC sp_rename '[app_generated].[SearchCore].GridConfigurationIdtempId', 'GridConfigurationId', 'COLUMN';


-- re-create indexes
CREATE INDEX [IX_SearchCore_GridConfigurationId] ON [app_generated].[SearchCore]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [app_generated].[WatchlistConfiguration] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_WatchlistConfiguration_GridConfigurationId] ON [app_generated].[WatchlistConfiguration]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIdtempId] = [source].[tempId]
FROM [app_generated].[WatchlistConfiguration] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [app_generated].[WatchlistConfiguration] DROP Column [GridConfigurationId]
EXEC sp_rename '[app_generated].[WatchlistConfiguration].GridConfigurationIdtempId', 'GridConfigurationId', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [app_generated].[WatchlistConfiguration] ALTER COLUMN [GridConfigurationId] int NOT NULL

-- re-create indexes
CREATE INDEX [IX_WatchlistConfiguration_GridConfigurationId] ON [app_generated].[WatchlistConfiguration]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [app_generated].[WorkingFolderConfiguration] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_WorkingFolderConfiguration_GridConfigurationId] ON [app_generated].[WorkingFolderConfiguration]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIdtempId] = [source].[tempId]
FROM [app_generated].[WorkingFolderConfiguration] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [app_generated].[WorkingFolderConfiguration] DROP Column [GridConfigurationId]
EXEC sp_rename '[app_generated].[WorkingFolderConfiguration].GridConfigurationIdtempId', 'GridConfigurationId', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [app_generated].[WorkingFolderConfiguration] ALTER COLUMN [GridConfigurationId] int NOT NULL

-- re-create indexes
CREATE INDEX [IX_WorkingFolderConfiguration_GridConfigurationId] ON [app_generated].[WorkingFolderConfiguration]([GridConfigurationId])

-- uuid PK columns have a default constraint
ALTER TABLE [config].[GridConfiguration] DROP CONSTRAINT [DF_GridConfiguration_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[GridConfiguration] DROP Column [Id]
EXEC sp_rename '[config].[GridConfiguration].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GridConfiguration] ADD CONSTRAINT [PK_GridConfiguration] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
ALTER TABLE [config].[EntityDetail] ADD CONSTRAINT [FK_EntityDetail_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [config].[EntityDetail] CHECK CONSTRAINT [FK_EntityDetail_GridConfiguration_GridConfigurationId];

ALTER TABLE [config].[GeoSpatialMaps] ADD CONSTRAINT [FK_GeoSpatialMaps_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [config].[GeoSpatialMaps] CHECK CONSTRAINT [FK_GeoSpatialMaps_GridConfiguration_GridConfigurationId];

ALTER TABLE [config].[GridColumn] ADD CONSTRAINT [FK_GridColumn_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [config].[GridColumn] CHECK CONSTRAINT [FK_GridColumn_GridConfiguration_GridConfigurationId];

ALTER TABLE [app_generated].[SearchCore] ADD CONSTRAINT [FK_SearchCore_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [app_generated].[SearchCore] CHECK CONSTRAINT [FK_SearchCore_GridConfiguration_GridConfigurationId];

ALTER TABLE [app_generated].[WatchlistConfiguration] ADD CONSTRAINT [FK_WatchlistConfiguration_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [app_generated].[WatchlistConfiguration] CHECK CONSTRAINT [FK_WatchlistConfiguration_GridConfiguration_GridConfigurationId];

ALTER TABLE [app_generated].[WorkingFolderConfiguration] ADD CONSTRAINT [FK_WorkingFolderConfiguration_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [app_generated].[WorkingFolderConfiguration] CHECK CONSTRAINT [FK_WorkingFolderConfiguration_GridConfiguration_GridConfigurationId];






------------------------------------------------
-- ROLLBACK FOR [config].[GroupRole]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[GroupRole]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[GroupRole] DROP CONSTRAINT [PK_GroupRole]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[GroupRole] DROP CONSTRAINT [DF_GroupRole_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[GroupRole] DROP Column [Id]
EXEC sp_rename '[config].[GroupRole].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GroupRole] ADD CONSTRAINT [PK_GroupRole] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- ROLLBACK FOR [config].[KeyValueFilter]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[KeyValueFilter]  ADD [tempId] int IDENTITY(1,1) not null 
ALTER TABLE  [config].[KeyValueFilterDetail]  ADD [KeyValueFilterIDtempId] int
GO

-- drop constraints, foreign keys first then PK
ALTER TABLE [config].[KeyValueFilterDetail] DROP CONSTRAINT [FK_KeyValueFilterDetail_KeyValueFilter_KeyValueFilterID]

ALTER TABLE [config].[KeyValueFilter] DROP CONSTRAINT [PK_KeyValueFilter]


------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[KeyValueFilter]  and [config].[KeyValueFilterDetail] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_KeyValueFilterDetail_KeyValueFilterID] ON [config].[KeyValueFilterDetail]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[KeyValueFilterIDtempId] = [source].[tempId]
FROM [config].[KeyValueFilterDetail] [target] INNER JOIN [config].[KeyValueFilter] [source] ON [source].[Key] = [target].[KeyValueFilterID]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[KeyValueFilterDetail] DROP Column [KeyValueFilterID]
EXEC sp_rename '[config].[KeyValueFilterDetail].KeyValueFilterIDtempId', 'KeyValueFilterID', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [config].[KeyValueFilterDetail] ALTER COLUMN [KeyValueFilterID] int NOT NULL

-- re-create indexes
CREATE INDEX [IX_KeyValueFilterDetail_KeyValueFilterID] ON [config].[KeyValueFilterDetail]([KeyValueFilterID])

-- uuid PK columns have a default constraint
ALTER TABLE [config].[KeyValueFilter] DROP CONSTRAINT [DF_KeyValueFilter_Key_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[KeyValueFilter] DROP Column [Key]
EXEC sp_rename '[config].[KeyValueFilter].tempId', 'Key', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[KeyValueFilter] ADD CONSTRAINT [PK_KeyValueFilter] PRIMARY KEY ([Key]);
-- Re-add foreign keys and check their validity
ALTER TABLE [config].[KeyValueFilterDetail] ADD CONSTRAINT [FK_KeyValueFilterDetail_KeyValueFilter_KeyValueFilterID] FOREIGN KEY ([KeyValueFilterID]) REFERENCES [config].[KeyValueFilter]([Key])
ALTER TABLE [config].[KeyValueFilterDetail] CHECK CONSTRAINT [FK_KeyValueFilterDetail_KeyValueFilter_KeyValueFilterID];






------------------------------------------------
-- ROLLBACK FOR [config].[KeyValueFilterDetail]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[KeyValueFilterDetail]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[KeyValueFilterDetail] DROP CONSTRAINT [PK_KeyValueFilterDetail]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[KeyValueFilterDetail] DROP CONSTRAINT [DF_KeyValueFilterDetail_RowID_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[KeyValueFilterDetail] DROP Column [RowID]
EXEC sp_rename '[config].[KeyValueFilterDetail].tempId', 'RowID', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[KeyValueFilterDetail] ADD CONSTRAINT [PK_KeyValueFilterDetail] PRIMARY KEY ([RowID]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- ROLLBACK FOR [config].[MenuComponent]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[MenuComponent]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[MenuComponent] DROP CONSTRAINT [PK_MenuComponent]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[MenuComponent] DROP CONSTRAINT [DF_MenuComponent_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[MenuComponent] DROP Column [Id]
EXEC sp_rename '[config].[MenuComponent].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[MenuComponent] ADD CONSTRAINT [PK_MenuComponent] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- ROLLBACK FOR [config].[MenuRole]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[MenuRole]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[MenuRole] DROP CONSTRAINT [PK_MenuRole]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[MenuRole] DROP CONSTRAINT [DF_MenuRole_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[MenuRole] DROP Column [Id]
EXEC sp_rename '[config].[MenuRole].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[MenuRole] ADD CONSTRAINT [PK_MenuRole] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- ROLLBACK FOR [config].[MiniProfileItemMapping]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[MiniProfileItemMapping]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[MiniProfileItemMapping] DROP CONSTRAINT [PK_MiniProfileItemMapping]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[MiniProfileItemMapping] DROP CONSTRAINT [DF_MiniProfileItemMapping_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[MiniProfileItemMapping] DROP Column Id
EXEC sp_rename '[config].[MiniProfileItemMapping].tempId', 'RowNumber', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[MiniProfileItemMapping] ADD CONSTRAINT [PK_MiniProfileItemMapping] PRIMARY KEY ([RowNumber]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- ROLLBACK FOR [config].[Scorecard]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[Scorecard]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[Scorecard] DROP CONSTRAINT [PK_Scorecard]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[Scorecard] DROP CONSTRAINT [DF_Scorecard_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[Scorecard] DROP Column [Id]
EXEC sp_rename '[config].[Scorecard].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[Scorecard] ADD CONSTRAINT [PK_Scorecard] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- ROLLBACK FOR [config].[SocialNetworkItemMapping]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[SocialNetworkItemMapping]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[SocialNetworkItemMapping] DROP CONSTRAINT [PK_SocialNetworkItemMapping]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[SocialNetworkItemMapping] DROP CONSTRAINT [DF_SocialNetworkItemMapping_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[SocialNetworkItemMapping] DROP Column [Id]
EXEC sp_rename '[config].[SocialNetworkItemMapping].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[SocialNetworkItemMapping] ADD CONSTRAINT [PK_SocialNetworkItemMapping] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity




