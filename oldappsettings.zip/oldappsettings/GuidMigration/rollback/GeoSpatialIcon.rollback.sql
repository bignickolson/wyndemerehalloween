



------------------------------------------------
-- ROLLBACK FOR [config].[GeoSpatialIcon]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[GeoSpatialIcon]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[GeoSpatialIcon] DROP CONSTRAINT [PK_GeoSpatialIcon]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[GeoSpatialIcon] DROP CONSTRAINT [DF_GeoSpatialIcon_RowID_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[GeoSpatialIcon] DROP Column [RowID]
EXEC sp_rename '[config].[GeoSpatialIcon].tempId', 'RowID', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GeoSpatialIcon] ADD CONSTRAINT [PK_GeoSpatialIcon] PRIMARY KEY ([RowID]);
-- Re-add foreign keys and check their validity
