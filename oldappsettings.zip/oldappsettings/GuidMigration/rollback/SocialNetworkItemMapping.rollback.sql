



------------------------------------------------
-- ROLLBACK FOR [config].[SocialNetworkItemMapping]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[SocialNetworkItemMapping]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[SocialNetworkItemMapping] DROP CONSTRAINT [PK_SocialNetworkItemMapping]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[SocialNetworkItemMapping] DROP CONSTRAINT [DF_SocialNetworkItemMapping_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[SocialNetworkItemMapping] DROP Column [Id]
EXEC sp_rename '[config].[SocialNetworkItemMapping].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[SocialNetworkItemMapping] ADD CONSTRAINT [PK_SocialNetworkItemMapping] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
