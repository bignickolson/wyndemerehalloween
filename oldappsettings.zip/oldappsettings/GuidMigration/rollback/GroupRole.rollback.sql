



------------------------------------------------
-- ROLLBACK FOR [config].[GroupRole]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[GroupRole]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[GroupRole] DROP CONSTRAINT [PK_GroupRole]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[GroupRole] DROP CONSTRAINT [DF_GroupRole_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[GroupRole] DROP Column [Id]
EXEC sp_rename '[config].[GroupRole].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GroupRole] ADD CONSTRAINT [PK_GroupRole] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
