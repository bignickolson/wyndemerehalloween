



------------------------------------------------
-- ROLLBACK FOR [config].[FEFilter]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[FEFilter]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[FEFilter] DROP CONSTRAINT [PK_FEFilter]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[FEFilter] DROP CONSTRAINT [DF_FEFilter_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[FEFilter] DROP Column [Id]
EXEC sp_rename '[config].[FEFilter].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[FEFilter] ADD CONSTRAINT [PK_FEFilter] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
