-- Compiled migration script for all tables 




------------------------------------------------
-- ROLLBACK FOR [config].[CaseItemDetail]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[CaseItemDetail]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[CaseItemDetail] DROP CONSTRAINT [PK_CaseItemDetail]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[CaseItemDetail] DROP CONSTRAINT [DF_CaseItemDetail_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[CaseItemDetail] DROP Column [Id]
EXEC sp_rename '[config].[CaseItemDetail].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[CaseItemDetail] ADD CONSTRAINT [PK_CaseItemDetail] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
