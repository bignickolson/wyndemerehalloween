



------------------------------------------------
-- ROLLBACK FOR [app_generated].[GeoNode]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [app_generated].[GeoNode]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [app_generated].[GeoNode] DROP CONSTRAINT [PK_GeoNode]
-- uuid PK columns have a default constraint
ALTER TABLE [app_generated].[GeoNode] DROP CONSTRAINT [DF_GeoNode_RowId_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [app_generated].[GeoNode] DROP Column [RowId]
EXEC sp_rename '[app_generated].[GeoNode].tempId', 'RowId', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [app_generated].[GeoNode] ADD CONSTRAINT [PK_GeoNode] PRIMARY KEY ([RowId]);
-- Re-add foreign keys and check their validity
