



------------------------------------------------
-- ROLLBACK FOR [config].[MiniProfileItemMapping]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[MiniProfileItemMapping]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[MiniProfileItemMapping] DROP CONSTRAINT [PK_MiniProfileItemMapping]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[MiniProfileItemMapping] DROP CONSTRAINT [DF_MiniProfileItemMapping_RowNumber_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[MiniProfileItemMapping] DROP Column [RowNumber]
EXEC sp_rename '[config].[MiniProfileItemMapping].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[MiniProfileItemMapping] ADD CONSTRAINT [PK_MiniProfileItemMapping] PRIMARY KEY ([RowNumber]);
-- Re-add foreign keys and check their validity
