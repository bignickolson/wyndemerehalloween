



------------------------------------------------
-- ROLLBACK FOR [config].[MenuComponent]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[MenuComponent]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[MenuComponent] DROP CONSTRAINT [PK_MenuComponent]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[MenuComponent] DROP CONSTRAINT [DF_MenuComponent_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[MenuComponent] DROP Column [Id]
EXEC sp_rename '[config].[MenuComponent].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[MenuComponent] ADD CONSTRAINT [PK_MenuComponent] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
