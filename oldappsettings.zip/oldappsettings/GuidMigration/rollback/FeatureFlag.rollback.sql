



------------------------------------------------
-- ROLLBACK FOR [config].[FeatureFlag]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[FeatureFlag]  ADD [tempId] int IDENTITY(1,1) not null 
ALTER TABLE  [app_generated].[MenuItem]  ADD [FeatureFlagIdtempId] int
GO

-- drop constraints, foreign keys first then PK
ALTER TABLE [app_generated].[MenuItem] DROP CONSTRAINT [FK_MenuItem_FeatureFlag_FeatureFlagId]

ALTER TABLE [config].[FeatureFlag] DROP CONSTRAINT [PK_FeatureFlag]


------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[FeatureFlag]  and [app_generated].[MenuItem] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_MenuItem_FeatureFlagId] ON [app_generated].[MenuItem]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[FeatureFlagIdtempId] = [source].[tempId]
FROM [app_generated].[MenuItem] [target] INNER JOIN [config].[FeatureFlag] [source] ON [source].[Id] = [target].[FeatureFlagId]

-- Drop old foreign key column and rename new one
ALTER TABLE [app_generated].[MenuItem] DROP Column [FeatureFlagId]
EXEC sp_rename '[app_generated].[MenuItem].FeatureFlagIdtempId', 'FeatureFlagId', 'COLUMN';


-- re-create indexes
CREATE INDEX [IX_MenuItem_FeatureFlagId] ON [app_generated].[MenuItem]([FeatureFlagId])

-- uuid PK columns have a default constraint
ALTER TABLE [config].[FeatureFlag] DROP CONSTRAINT [DF_FeatureFlag_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[FeatureFlag] DROP Column [Id]
EXEC sp_rename '[config].[FeatureFlag].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[FeatureFlag] ADD CONSTRAINT [PK_FeatureFlag] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
ALTER TABLE [app_generated].[MenuItem] ADD CONSTRAINT [FK_MenuItem_FeatureFlag_FeatureFlagId] FOREIGN KEY ([FeatureFlagId]) REFERENCES [config].[FeatureFlag]([Id])
ALTER TABLE [app_generated].[MenuItem] CHECK CONSTRAINT [FK_MenuItem_FeatureFlag_FeatureFlagId];

