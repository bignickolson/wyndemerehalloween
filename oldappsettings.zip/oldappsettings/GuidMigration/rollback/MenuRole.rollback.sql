



------------------------------------------------
-- ROLLBACK FOR [config].[MenuRole]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[MenuRole]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[MenuRole] DROP CONSTRAINT [PK_MenuRole]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[MenuRole] DROP CONSTRAINT [DF_MenuRole_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[MenuRole] DROP Column [Id]
EXEC sp_rename '[config].[MenuRole].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[MenuRole] ADD CONSTRAINT [PK_MenuRole] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
