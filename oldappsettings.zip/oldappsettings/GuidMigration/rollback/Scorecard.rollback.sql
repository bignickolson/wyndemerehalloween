



------------------------------------------------
-- ROLLBACK FOR [config].[Scorecard]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[Scorecard]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[Scorecard] DROP CONSTRAINT [PK_Scorecard]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[Scorecard] DROP CONSTRAINT [DF_Scorecard_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[Scorecard] DROP Column [Id]
EXEC sp_rename '[config].[Scorecard].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[Scorecard] ADD CONSTRAINT [PK_Scorecard] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
