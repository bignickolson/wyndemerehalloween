



------------------------------------------------
-- ROLLBACK FOR [config].[GridColumn]
------------------------------------------------
-- Create new tempId columns on tables
ALTER TABLE  [config].[GridColumn]  ADD [tempId] int IDENTITY(1,1) not null 
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[GridColumn] DROP CONSTRAINT [PK_GridColumn]
-- uuid PK columns have a default constraint
ALTER TABLE [config].[GridColumn] DROP CONSTRAINT [DF_GridColumn_Id_uuid];


-- Drop old primary key column and rename new one
ALTER TABLE [config].[GridColumn] DROP Column [Id]
EXEC sp_rename '[config].[GridColumn].tempId', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GridColumn] ADD CONSTRAINT [PK_GridColumn] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
