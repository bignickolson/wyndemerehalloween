$FilePath = "F:\nolsona\FraudCaster_FraudDetect\Pondera.Data\ModelConfigurations\NoteTypesConfiguration.cs"
$ClassName = "NoteTypes"
$IdProp = "Id"
$NameProp = "Name"

$fileContent = Get-Content -Path $FilePath -Raw


$idRegex = [regex]::new("$IdProp = Guid\.Parse\(`"(.*)`"\).*$NameProp = `"(.*)`"")

$matches = $idRegex.Matches($fileContent)
Write-host "public static class $($ClassName)Ids {"
foreach ($match in $matches) {
    Write-Host "public static readonly Guid $($match.Groups[2].Value) = Guid.Parse(`"$($match.Groups[1].Value)`");"
    
}

Write-host "}"
