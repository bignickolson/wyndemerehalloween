-- Compiled migration script for all tables 




------------------------------------------------
-- MIGRATION FOR [config].[CaseItemDetail]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[CaseItemDetail]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_CaseItemDetail_Id_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[CaseItemDetail] DROP CONSTRAINT [PK_CaseItemDetail]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[CaseItemDetail] DROP Column [Id]
EXEC sp_rename '[config].[CaseItemDetail].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[CaseItemDetail] ADD CONSTRAINT [PK_CaseItemDetail] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- MIGRATION FOR [config].[ClaimDetail]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[ClaimDetail]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_ClaimDetail_Id_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[ClaimDetail] DROP CONSTRAINT [PK_ClaimDetail]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[ClaimDetail] DROP Column [Id]
EXEC sp_rename '[config].[ClaimDetail].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[ClaimDetail] ADD CONSTRAINT [PK_ClaimDetail] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- MIGRATION FOR [config].[EntityDetail]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[EntityDetail]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_EntityDetail_Id_uuid] DEFAULT newid()
ALTER TABLE  [config].[EntityDetailItem]  ADD [EntityDetailIduuid] uniqueidentifier
GO

-- drop constraints, foreign keys first then PK
ALTER TABLE [config].[EntityDetailItem] DROP CONSTRAINT [FK_EntityDetailItem_EntityDetail_EntityDetailId]

ALTER TABLE [config].[EntityDetail] DROP CONSTRAINT [PK_EntityDetail]


------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[EntityDetail]  and [config].[EntityDetailItem] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_EntityDetailItem_EntityDetailId] ON [config].[EntityDetailItem]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[EntityDetailIduuid] = [source].[uuid]
FROM [config].[EntityDetailItem] [target] INNER JOIN [config].[EntityDetail] [source] ON [source].[Id] = [target].[EntityDetailId]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[EntityDetailItem] DROP Column [EntityDetailId]
EXEC sp_rename '[config].[EntityDetailItem].EntityDetailIduuid', 'EntityDetailId', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [config].[EntityDetailItem] ALTER COLUMN [EntityDetailId] uniqueidentifier NOT NULL

-- re-create indexes
CREATE INDEX [IX_EntityDetailItem_EntityDetailId] ON [config].[EntityDetailItem]([EntityDetailId])


-- Drop old primary key column and rename new one
ALTER TABLE [config].[EntityDetail] DROP Column [Id]
EXEC sp_rename '[config].[EntityDetail].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[EntityDetail] ADD CONSTRAINT [PK_EntityDetail] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
ALTER TABLE [config].[EntityDetailItem] ADD CONSTRAINT [FK_EntityDetailItem_EntityDetail_EntityDetailId] FOREIGN KEY ([EntityDetailId]) REFERENCES [config].[EntityDetail]([Id])
ALTER TABLE [config].[EntityDetailItem] CHECK CONSTRAINT [FK_EntityDetailItem_EntityDetail_EntityDetailId];






------------------------------------------------
-- MIGRATION FOR [config].[EntityDetailItem]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[EntityDetailItem]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_EntityDetailItem_Id_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[EntityDetailItem] DROP CONSTRAINT [PK_EntityDetailItem]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[EntityDetailItem] DROP Column [Id]
EXEC sp_rename '[config].[EntityDetailItem].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[EntityDetailItem] ADD CONSTRAINT [PK_EntityDetailItem] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- MIGRATION FOR [config].[FeatureFlag]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[FeatureFlag]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_FeatureFlag_Id_uuid] DEFAULT newid()
ALTER TABLE  [app_generated].[MenuItem]  ADD [FeatureFlagIduuid] uniqueidentifier
GO

-- drop constraints, foreign keys first then PK
ALTER TABLE [app_generated].[MenuItem] DROP CONSTRAINT [FK_MenuItem_FeatureFlag_FeatureFlagId]

ALTER TABLE [config].[FeatureFlag] DROP CONSTRAINT [PK_FeatureFlag]


------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[FeatureFlag]  and [app_generated].[MenuItem] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_MenuItem_FeatureFlagId] ON [app_generated].[MenuItem]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[FeatureFlagIduuid] = [source].[uuid]
FROM [app_generated].[MenuItem] [target] INNER JOIN [config].[FeatureFlag] [source] ON [source].[Id] = [target].[FeatureFlagId]

-- Drop old foreign key column and rename new one
ALTER TABLE [app_generated].[MenuItem] DROP Column [FeatureFlagId]
EXEC sp_rename '[app_generated].[MenuItem].FeatureFlagIduuid', 'FeatureFlagId', 'COLUMN';


-- re-create indexes
CREATE INDEX [IX_MenuItem_FeatureFlagId] ON [app_generated].[MenuItem]([FeatureFlagId])


-- Drop old primary key column and rename new one
ALTER TABLE [config].[FeatureFlag] DROP Column [Id]
EXEC sp_rename '[config].[FeatureFlag].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[FeatureFlag] ADD CONSTRAINT [PK_FeatureFlag] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
ALTER TABLE [app_generated].[MenuItem] ADD CONSTRAINT [FK_MenuItem_FeatureFlag_FeatureFlagId] FOREIGN KEY ([FeatureFlagId]) REFERENCES [config].[FeatureFlag]([Id])
ALTER TABLE [app_generated].[MenuItem] CHECK CONSTRAINT [FK_MenuItem_FeatureFlag_FeatureFlagId];






------------------------------------------------
-- MIGRATION FOR [config].[FEFilter]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[FEFilter]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_FEFilter_Id_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[FEFilter] DROP CONSTRAINT [PK_FEFilter]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[FEFilter] DROP Column [Id]
EXEC sp_rename '[config].[FEFilter].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[FEFilter] ADD CONSTRAINT [PK_FEFilter] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- MIGRATION FOR [app_generated].[GeoNode]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [app_generated].[GeoNode]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_GeoNode_RowId_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [app_generated].[GeoNode] DROP CONSTRAINT [PK_GeoNode]

-- Drop old primary key column and rename new one
ALTER TABLE [app_generated].[GeoNode] DROP Column [RowId]
EXEC sp_rename '[app_generated].[GeoNode].uuid', 'RowId', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [app_generated].[GeoNode] ADD CONSTRAINT [PK_GeoNode] PRIMARY KEY ([RowId]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- MIGRATION FOR [config].[GeoSpatialIcon]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[GeoSpatialIcon]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_GeoSpatialIcon_RowID_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[GeoSpatialIcon] DROP CONSTRAINT [PK_GeoSpatialIcon]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[GeoSpatialIcon] DROP Column [RowID]
EXEC sp_rename '[config].[GeoSpatialIcon].uuid', 'RowID', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GeoSpatialIcon] ADD CONSTRAINT [PK_GeoSpatialIcon] PRIMARY KEY ([RowID]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- MIGRATION FOR [config].[GridColumn]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[GridColumn]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_GridColumn_Id_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[GridColumn] DROP CONSTRAINT [PK_GridColumn]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[GridColumn] DROP Column [Id]
EXEC sp_rename '[config].[GridColumn].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GridColumn] ADD CONSTRAINT [PK_GridColumn] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- MIGRATION FOR [config].[GridConfiguration]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[GridConfiguration]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_GridConfiguration_Id_uuid] DEFAULT newid()
ALTER TABLE  [config].[EntityDetail]  ADD [GridConfigurationIduuid] uniqueidentifier
ALTER TABLE  [config].[GeoSpatialMaps]  ADD [GridConfigurationIduuid] uniqueidentifier
ALTER TABLE  [config].[GridColumn]  ADD [GridConfigurationIduuid] uniqueidentifier
ALTER TABLE  [app_generated].[SearchCore]  ADD [GridConfigurationIduuid] uniqueidentifier
ALTER TABLE  [app_generated].[WatchlistConfiguration]  ADD [GridConfigurationIduuid] uniqueidentifier
ALTER TABLE  [app_generated].[WorkingFolderConfiguration]  ADD [GridConfigurationIduuid] uniqueidentifier
GO

-- drop constraints, foreign keys first then PK
ALTER TABLE [config].[EntityDetail] DROP CONSTRAINT [FK_EntityDetail_GridConfiguration_GridConfigurationId]
ALTER TABLE [config].[GeoSpatialMaps] DROP CONSTRAINT [FK_GeoSpatialMaps_GridConfiguration_GridConfigurationId]
ALTER TABLE [config].[GridColumn] DROP CONSTRAINT [FK_GridColumn_GridConfiguration_GridConfigurationId]
ALTER TABLE [app_generated].[SearchCore] DROP CONSTRAINT [FK_SearchCore_GridConfiguration_GridConfigurationId]
ALTER TABLE [app_generated].[WatchlistConfiguration] DROP CONSTRAINT [FK_WatchlistConfiguration_GridConfiguration_GridConfigurationId]
ALTER TABLE [app_generated].[WorkingFolderConfiguration] DROP CONSTRAINT [FK_WorkingFolderConfiguration_GridConfiguration_GridConfigurationId]

ALTER TABLE [config].[GridConfiguration] DROP CONSTRAINT [PK_GridConfiguration]


------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [config].[EntityDetail] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_EntityDetail_GridConfigurationId] ON [config].[EntityDetail]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIduuid] = [source].[uuid]
FROM [config].[EntityDetail] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[EntityDetail] DROP Column [GridConfigurationId]
EXEC sp_rename '[config].[EntityDetail].GridConfigurationIduuid', 'GridConfigurationId', 'COLUMN';


-- re-create indexes
CREATE INDEX [IX_EntityDetail_GridConfigurationId] ON [config].[EntityDetail]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [config].[GeoSpatialMaps] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_GeoSpatialMaps_GridConfigurationId] ON [config].[GeoSpatialMaps]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIduuid] = [source].[uuid]
FROM [config].[GeoSpatialMaps] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[GeoSpatialMaps] DROP Column [GridConfigurationId]
EXEC sp_rename '[config].[GeoSpatialMaps].GridConfigurationIduuid', 'GridConfigurationId', 'COLUMN';


-- re-create indexes
CREATE INDEX [IX_GeoSpatialMaps_GridConfigurationId] ON [config].[GeoSpatialMaps]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [config].[GridColumn] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_GridColumn_GridConfigurationId] ON [config].[GridColumn]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIduuid] = [source].[uuid]
FROM [config].[GridColumn] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[GridColumn] DROP Column [GridConfigurationId]
EXEC sp_rename '[config].[GridColumn].GridConfigurationIduuid', 'GridConfigurationId', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [config].[GridColumn] ALTER COLUMN [GridConfigurationId] uniqueidentifier NOT NULL

-- re-create indexes
CREATE INDEX [IX_GridColumn_GridConfigurationId] ON [config].[GridColumn]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [app_generated].[SearchCore] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_SearchCore_GridConfigurationId] ON [app_generated].[SearchCore]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIduuid] = [source].[uuid]
FROM [app_generated].[SearchCore] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [app_generated].[SearchCore] DROP Column [GridConfigurationId]
EXEC sp_rename '[app_generated].[SearchCore].GridConfigurationIduuid', 'GridConfigurationId', 'COLUMN';


-- re-create indexes
CREATE INDEX [IX_SearchCore_GridConfigurationId] ON [app_generated].[SearchCore]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [app_generated].[WatchlistConfiguration] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_WatchlistConfiguration_GridConfigurationId] ON [app_generated].[WatchlistConfiguration]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIduuid] = [source].[uuid]
FROM [app_generated].[WatchlistConfiguration] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [app_generated].[WatchlistConfiguration] DROP Column [GridConfigurationId]
EXEC sp_rename '[app_generated].[WatchlistConfiguration].GridConfigurationIduuid', 'GridConfigurationId', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [app_generated].[WatchlistConfiguration] ALTER COLUMN [GridConfigurationId] uniqueidentifier NOT NULL

-- re-create indexes
CREATE INDEX [IX_WatchlistConfiguration_GridConfigurationId] ON [app_generated].[WatchlistConfiguration]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [app_generated].[WorkingFolderConfiguration] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_WorkingFolderConfiguration_GridConfigurationId] ON [app_generated].[WorkingFolderConfiguration]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIduuid] = [source].[uuid]
FROM [app_generated].[WorkingFolderConfiguration] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [app_generated].[WorkingFolderConfiguration] DROP Column [GridConfigurationId]
EXEC sp_rename '[app_generated].[WorkingFolderConfiguration].GridConfigurationIduuid', 'GridConfigurationId', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [app_generated].[WorkingFolderConfiguration] ALTER COLUMN [GridConfigurationId] uniqueidentifier NOT NULL

-- re-create indexes
CREATE INDEX [IX_WorkingFolderConfiguration_GridConfigurationId] ON [app_generated].[WorkingFolderConfiguration]([GridConfigurationId])


-- Drop old primary key column and rename new one
ALTER TABLE [config].[GridConfiguration] DROP Column [Id]
EXEC sp_rename '[config].[GridConfiguration].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GridConfiguration] ADD CONSTRAINT [PK_GridConfiguration] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
ALTER TABLE [config].[EntityDetail] ADD CONSTRAINT [FK_EntityDetail_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [config].[EntityDetail] CHECK CONSTRAINT [FK_EntityDetail_GridConfiguration_GridConfigurationId];

ALTER TABLE [config].[GeoSpatialMaps] ADD CONSTRAINT [FK_GeoSpatialMaps_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [config].[GeoSpatialMaps] CHECK CONSTRAINT [FK_GeoSpatialMaps_GridConfiguration_GridConfigurationId];

ALTER TABLE [config].[GridColumn] ADD CONSTRAINT [FK_GridColumn_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [config].[GridColumn] CHECK CONSTRAINT [FK_GridColumn_GridConfiguration_GridConfigurationId];

ALTER TABLE [app_generated].[SearchCore] ADD CONSTRAINT [FK_SearchCore_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [app_generated].[SearchCore] CHECK CONSTRAINT [FK_SearchCore_GridConfiguration_GridConfigurationId];

ALTER TABLE [app_generated].[WatchlistConfiguration] ADD CONSTRAINT [FK_WatchlistConfiguration_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [app_generated].[WatchlistConfiguration] CHECK CONSTRAINT [FK_WatchlistConfiguration_GridConfiguration_GridConfigurationId];

ALTER TABLE [app_generated].[WorkingFolderConfiguration] ADD CONSTRAINT [FK_WorkingFolderConfiguration_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [app_generated].[WorkingFolderConfiguration] CHECK CONSTRAINT [FK_WorkingFolderConfiguration_GridConfiguration_GridConfigurationId];






------------------------------------------------
-- MIGRATION FOR [config].[GroupRole]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[GroupRole]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_GroupRole_Id_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[GroupRole] DROP CONSTRAINT [PK_GroupRole]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[GroupRole] DROP Column [Id]
EXEC sp_rename '[config].[GroupRole].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GroupRole] ADD CONSTRAINT [PK_GroupRole] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- MIGRATION FOR [config].[KeyValueFilter]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[KeyValueFilter]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_KeyValueFilter_Key_uuid] DEFAULT newid()
ALTER TABLE  [config].[KeyValueFilterDetail]  ADD [KeyValueFilterIDuuid] uniqueidentifier
GO

-- drop constraints, foreign keys first then PK
ALTER TABLE [config].[KeyValueFilterDetail] DROP CONSTRAINT [FK_KeyValueFilterDetail_KeyValueFilter_KeyValueFilterID]

ALTER TABLE [config].[KeyValueFilter] DROP CONSTRAINT [PK_KeyValueFilter]


------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[KeyValueFilter]  and [config].[KeyValueFilterDetail] 
------------------------------------------------
-- drop indexes 
DROP INDEX [IX_KeyValueFilterDetail_KeyValueFilterID] ON [config].[KeyValueFilterDetail]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[KeyValueFilterIDuuid] = [source].[uuid]
FROM [config].[KeyValueFilterDetail] [target] INNER JOIN [config].[KeyValueFilter] [source] ON [source].[Key] = [target].[KeyValueFilterID]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[KeyValueFilterDetail] DROP Column [KeyValueFilterID]
EXEC sp_rename '[config].[KeyValueFilterDetail].KeyValueFilterIDuuid', 'KeyValueFilterID', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [config].[KeyValueFilterDetail] ALTER COLUMN [KeyValueFilterID] uniqueidentifier NOT NULL

-- re-create indexes
CREATE INDEX [IX_KeyValueFilterDetail_KeyValueFilterID] ON [config].[KeyValueFilterDetail]([KeyValueFilterID])


-- Drop old primary key column and rename new one
ALTER TABLE [config].[KeyValueFilter] DROP Column [Key]
EXEC sp_rename '[config].[KeyValueFilter].uuid', 'Key', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[KeyValueFilter] ADD CONSTRAINT [PK_KeyValueFilter] PRIMARY KEY ([Key]);
-- Re-add foreign keys and check their validity
ALTER TABLE [config].[KeyValueFilterDetail] ADD CONSTRAINT [FK_KeyValueFilterDetail_KeyValueFilter_KeyValueFilterID] FOREIGN KEY ([KeyValueFilterID]) REFERENCES [config].[KeyValueFilter]([Key])
ALTER TABLE [config].[KeyValueFilterDetail] CHECK CONSTRAINT [FK_KeyValueFilterDetail_KeyValueFilter_KeyValueFilterID];






------------------------------------------------
-- MIGRATION FOR [config].[KeyValueFilterDetail]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[KeyValueFilterDetail]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_KeyValueFilterDetail_RowID_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[KeyValueFilterDetail] DROP CONSTRAINT [PK_KeyValueFilterDetail]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[KeyValueFilterDetail] DROP Column [RowID]
EXEC sp_rename '[config].[KeyValueFilterDetail].uuid', 'RowID', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[KeyValueFilterDetail] ADD CONSTRAINT [PK_KeyValueFilterDetail] PRIMARY KEY ([RowID]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- MIGRATION FOR [config].[MenuComponent]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[MenuComponent]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_MenuComponent_Id_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[MenuComponent] DROP CONSTRAINT [PK_MenuComponent]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[MenuComponent] DROP Column [Id]
EXEC sp_rename '[config].[MenuComponent].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[MenuComponent] ADD CONSTRAINT [PK_MenuComponent] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- MIGRATION FOR [config].[MenuRole]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[MenuRole]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_MenuRole_Id_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[MenuRole] DROP CONSTRAINT [PK_MenuRole]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[MenuRole] DROP Column [Id]
EXEC sp_rename '[config].[MenuRole].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[MenuRole] ADD CONSTRAINT [PK_MenuRole] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- MIGRATION FOR [config].[MiniProfileItemMapping]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[MiniProfileItemMapping]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_MiniProfileItemMapping_ID_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[MiniProfileItemMapping] DROP CONSTRAINT [PK_MiniProfileItemMapping]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[MiniProfileItemMapping] DROP Column [RowNumber]
EXEC sp_rename '[config].[MiniProfileItemMapping].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[MiniProfileItemMapping] ADD CONSTRAINT [PK_MiniProfileItemMapping] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- MIGRATION FOR [config].[Scorecard]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[Scorecard]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_Scorecard_Id_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[Scorecard] DROP CONSTRAINT [PK_Scorecard]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[Scorecard] DROP Column [Id]
EXEC sp_rename '[config].[Scorecard].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[Scorecard] ADD CONSTRAINT [PK_Scorecard] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity





------------------------------------------------
-- MIGRATION FOR [config].[SocialNetworkItemMapping]
------------------------------------------------
-- Create new uuid columns on tables
ALTER TABLE  [config].[SocialNetworkItemMapping]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_SocialNetworkItemMapping_Id_uuid] DEFAULT newid()
GO

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[SocialNetworkItemMapping] DROP CONSTRAINT [PK_SocialNetworkItemMapping]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[SocialNetworkItemMapping] DROP Column [Id]
EXEC sp_rename '[config].[SocialNetworkItemMapping].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[SocialNetworkItemMapping] ADD CONSTRAINT [PK_SocialNetworkItemMapping] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity




