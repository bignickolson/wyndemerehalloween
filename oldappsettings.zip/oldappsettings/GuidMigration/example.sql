ALTER TABLE ref.NoteTypes ADD uuid uniqueidentifier not null default newsequentialid()
ALTER TABLE app_generated.Notes ADD NoteTypeuuid uniqueidentifier 
go

UPDATE app_generated.Notes
SET
	NoteTypeuuid = nt.uuid
FROM app_generated.Notes INNER JOIN ref.NoteTypes nt on nt.Id = NoteTypeId

ALTER TABLE app_generated.Notes DROP CONSTRAINT FK_Notes_NoteTypes_NoteTypeId
ALTER TABLE ref.NoteTypes DROP CONSTRAINT PK_NoteTypes

DROP INDEX [IX_Notes_NoteTypeId] ON [app_generated].[Notes]

ALTER TABLE app_generated.Notes DROP Column NoteTypeId
ALTER TABLE ref.NoteTypes DROP Column Id

EXEC sp_rename 'ref.NoteTypes.uuid', 'Id', 'COLUMN';
EXEC sp_rename 'app_generated.Notes.NoteTypeuuid', 'NoteTypeId', 'COLUMN';

ALTER TABLE ref.NoteTypes ADD CONSTRAINT PK_NoteTypes PRIMARY KEY (Id);

-- add fk
ALTER TABLE app_generated.Notes ADD CONSTRAINT FK_Notes_NoteTypes_NoteTypeId FOREIGN KEY (NoteTypeId) REFERENCES ref.NoteTypes(Id)

-- Ensure the foreign key is properly enforced
ALTER TABLE app_generated.Notes CHECK CONSTRAINT FK_Notes_NoteTypes_NoteTypeId;

CREATE INDEX [IX_Notes_NoteTypeId] ON [app_generated].[Notes](NoteTypeId)


