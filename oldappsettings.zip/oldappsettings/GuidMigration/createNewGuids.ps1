$FilePath = "F:\nolsona\FraudCaster_FraudDetect\Pondera.Data\ModelConfigurations\EntityDetailIItemConfiguration.cs"
$RegexPattern = "index\+\+,"


# Read file content
$content = Get-Content -Raw -Path $FilePath

# Initialize counter for the replacement target
$newGuid = [Guid]::NewGuid().ToString()

# Replace matches with <target1>, <target2>, etc.
$updatedContent = [regex]::Replace($content, $RegexPattern, {
    param($match)
    $script:newGuid = [Guid]::NewGuid().ToString()
    return "Guid.Parse(`"$newGuid`"),"
})

# Write the updated content back to the file
Set-Content -Path $FilePath -Value $updatedContent

Write-Host "Replacements complete. File updated."
