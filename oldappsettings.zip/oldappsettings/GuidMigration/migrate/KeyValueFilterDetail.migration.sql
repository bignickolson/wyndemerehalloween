------------------------------------------------
-- MIGRATION FOR [config].[KeyValueFilterDetail]
------------------------------------------------

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[KeyValueFilterDetail] DROP CONSTRAINT IF EXISTS [PK_KeyValueFilterDetail]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[KeyValueFilterDetail] DROP Column [RowID]
EXEC sp_rename '[config].[KeyValueFilterDetail].uuid', 'RowID', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[KeyValueFilterDetail] ADD CONSTRAINT [PK_KeyValueFilterDetail] PRIMARY KEY ([RowID]);
-- Re-add foreign keys and check their validity
