------------------------------------------------
-- MIGRATION FOR [config].[EntityDetail]
------------------------------------------------

-- drop constraints, foreign keys first then PK
ALTER TABLE [config].[EntityDetailItem] DROP CONSTRAINT IF EXISTS [FK_EntityDetailItem_EntityDetail_EntityDetailId]

ALTER TABLE [config].[EntityDetail] DROP CONSTRAINT IF EXISTS [PK_EntityDetail]


------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[EntityDetail]  and [config].[EntityDetailItem] 
------------------------------------------------
-- drop indexes 
DROP INDEX IF EXISTS [IX_EntityDetailItem_EntityDetailId] ON [config].[EntityDetailItem]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[EntityDetailIduuid] = [source].[uuid]
FROM [config].[EntityDetailItem] [target] INNER JOIN [config].[EntityDetail] [source] ON [source].[Id] = [target].[EntityDetailId]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[EntityDetailItem] DROP Column [EntityDetailId]
EXEC sp_rename '[config].[EntityDetailItem].EntityDetailIduuid', 'EntityDetailId', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [config].[EntityDetailItem] ALTER COLUMN [EntityDetailId] uniqueidentifier NOT NULL

-- re-create indexes
CREATE INDEX [IX_EntityDetailItem_EntityDetailId] ON [config].[EntityDetailItem]([EntityDetailId])


-- Drop old primary key column and rename new one
ALTER TABLE [config].[EntityDetail] DROP Column [Id]
EXEC sp_rename '[config].[EntityDetail].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[EntityDetail] ADD CONSTRAINT [PK_EntityDetail] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
ALTER TABLE [config].[EntityDetailItem] ADD CONSTRAINT [FK_EntityDetailItem_EntityDetail_EntityDetailId] FOREIGN KEY ([EntityDetailId]) REFERENCES [config].[EntityDetail]([Id])
ALTER TABLE [config].[EntityDetailItem] CHECK CONSTRAINT [FK_EntityDetailItem_EntityDetail_EntityDetailId];

