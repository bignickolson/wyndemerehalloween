------------------------------------------------
-- MIGRATION FOR [config].[MiniProfileItemMapping]
------------------------------------------------

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[MiniProfileItemMapping] DROP CONSTRAINT IF EXISTS [PK_MiniProfileItemMapping]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[MiniProfileItemMapping] DROP Column [RowNumber]
EXEC sp_rename '[config].[MiniProfileItemMapping].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[MiniProfileItemMapping] ADD CONSTRAINT [PK_MiniProfileItemMapping] PRIMARY KEY ([RowNumber]);
-- Re-add foreign keys and check their validity
