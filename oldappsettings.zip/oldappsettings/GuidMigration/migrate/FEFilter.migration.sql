------------------------------------------------
-- MIGRATION FOR [config].[FEFilter]
------------------------------------------------

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[FEFilter] DROP CONSTRAINT IF EXISTS [PK_FEFilter]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[FEFilter] DROP Column [Id]
EXEC sp_rename '[config].[FEFilter].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[FEFilter] ADD CONSTRAINT [PK_FEFilter] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
