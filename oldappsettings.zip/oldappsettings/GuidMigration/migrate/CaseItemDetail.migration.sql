-- Compiled migration script for all tables 

-- Create new uuid columns on tables in one batch so they are available for update in the rest of the script
ALTER TABLE  [config].[CaseItemDetail]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_CaseItemDetail_Id_uuid] DEFAULT newid()
ALTER TABLE  [config].[ClaimDetail]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_ClaimDetail_Id_uuid] DEFAULT newid()
ALTER TABLE  [config].[EntityDetail]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_EntityDetail_Id_uuid] DEFAULT newid()
ALTER TABLE  [config].[EntityDetailItem]  ADD [EntityDetailIduuid] uniqueidentifier
ALTER TABLE  [config].[EntityDetailItem]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_EntityDetailItem_Id_uuid] DEFAULT newid()
ALTER TABLE  [config].[FeatureFlag]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_FeatureFlag_Id_uuid] DEFAULT newid()
ALTER TABLE  [app_generated].[MenuItem]  ADD [FeatureFlagIduuid] uniqueidentifier
ALTER TABLE  [config].[FEFilter]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_FEFilter_Id_uuid] DEFAULT newid()
ALTER TABLE  [app_generated].[GeoNode]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_GeoNode_RowId_uuid] DEFAULT newid()
ALTER TABLE  [config].[GeoSpatialIcon]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_GeoSpatialIcon_RowID_uuid] DEFAULT newid()
ALTER TABLE  [config].[GridColumn]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_GridColumn_Id_uuid] DEFAULT newid()
ALTER TABLE  [config].[GridConfiguration]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_GridConfiguration_Id_uuid] DEFAULT newid()
ALTER TABLE  [config].[EntityDetail]  ADD [GridConfigurationIduuid] uniqueidentifier
ALTER TABLE  [config].[GeoSpatialMaps]  ADD [GridConfigurationIduuid] uniqueidentifier
ALTER TABLE  [config].[GridColumn]  ADD [GridConfigurationIduuid] uniqueidentifier
ALTER TABLE  [app_generated].[SearchCore]  ADD [GridConfigurationIduuid] uniqueidentifier
ALTER TABLE  [app_generated].[WatchlistConfiguration]  ADD [GridConfigurationIduuid] uniqueidentifier
ALTER TABLE  [app_generated].[WorkingFolderConfiguration]  ADD [GridConfigurationIduuid] uniqueidentifier
ALTER TABLE  [config].[GroupRole]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_GroupRole_Id_uuid] DEFAULT newid()
ALTER TABLE  [config].[KeyValueFilter]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_KeyValueFilter_Key_uuid] DEFAULT newid()
ALTER TABLE  [config].[KeyValueFilterDetail]  ADD [KeyValueFilterIDuuid] uniqueidentifier
ALTER TABLE  [config].[KeyValueFilterDetail]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_KeyValueFilterDetail_RowID_uuid] DEFAULT newid()
ALTER TABLE  [config].[MenuComponent]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_MenuComponent_Id_uuid] DEFAULT newid()
ALTER TABLE  [config].[MenuRole]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_MenuRole_Id_uuid] DEFAULT newid()
ALTER TABLE  [config].[MiniProfileItemMapping]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_MiniProfileItemMapping_RowNumber_uuid] DEFAULT newid()
ALTER TABLE  [config].[Scorecard]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_Scorecard_Id_uuid] DEFAULT newid()
ALTER TABLE  [config].[SocialNetworkItemMapping]  ADD [uuid] uniqueidentifier not null  CONSTRAINT [DF_SocialNetworkItemMapping_Id_uuid] DEFAULT newid()

GO

------------------------------------------------
-- MIGRATION FOR [config].[CaseItemDetail]
------------------------------------------------

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[CaseItemDetail] DROP CONSTRAINT IF EXISTS [PK_CaseItemDetail]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[CaseItemDetail] DROP Column [Id]
EXEC sp_rename '[config].[CaseItemDetail].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[CaseItemDetail] ADD CONSTRAINT [PK_CaseItemDetail] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
