------------------------------------------------
-- MIGRATION FOR [config].[GridColumn]
------------------------------------------------

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[GridColumn] DROP CONSTRAINT IF EXISTS [PK_GridColumn]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[GridColumn] DROP Column [Id]
EXEC sp_rename '[config].[GridColumn].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GridColumn] ADD CONSTRAINT [PK_GridColumn] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
