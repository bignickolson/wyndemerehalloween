------------------------------------------------
-- MIGRATION FOR [config].[ClaimDetail]
------------------------------------------------

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[ClaimDetail] DROP CONSTRAINT IF EXISTS [PK_ClaimDetail]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[ClaimDetail] DROP Column [Id]
EXEC sp_rename '[config].[ClaimDetail].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[ClaimDetail] ADD CONSTRAINT [PK_ClaimDetail] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
