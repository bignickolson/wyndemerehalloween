------------------------------------------------
-- MIGRATION FOR [config].[EntityDetailItem]
------------------------------------------------

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[EntityDetailItem] DROP CONSTRAINT IF EXISTS [PK_EntityDetailItem]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[EntityDetailItem] DROP Column [Id]
EXEC sp_rename '[config].[EntityDetailItem].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[EntityDetailItem] ADD CONSTRAINT [PK_EntityDetailItem] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
