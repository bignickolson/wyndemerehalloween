------------------------------------------------
-- MIGRATION FOR [config].[MenuComponent]
------------------------------------------------

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[MenuComponent] DROP CONSTRAINT IF EXISTS [PK_MenuComponent]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[MenuComponent] DROP Column [Id]
EXEC sp_rename '[config].[MenuComponent].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[MenuComponent] ADD CONSTRAINT [PK_MenuComponent] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
