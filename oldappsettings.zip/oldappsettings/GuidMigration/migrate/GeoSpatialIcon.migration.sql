------------------------------------------------
-- MIGRATION FOR [config].[GeoSpatialIcon]
------------------------------------------------

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[GeoSpatialIcon] DROP CONSTRAINT IF EXISTS [PK_GeoSpatialIcon]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[GeoSpatialIcon] DROP Column [RowID]
EXEC sp_rename '[config].[GeoSpatialIcon].uuid', 'RowID', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GeoSpatialIcon] ADD CONSTRAINT [PK_GeoSpatialIcon] PRIMARY KEY ([RowID]);
-- Re-add foreign keys and check their validity
