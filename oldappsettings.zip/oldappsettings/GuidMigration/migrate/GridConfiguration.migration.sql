------------------------------------------------
-- MIGRATION FOR [config].[GridConfiguration]
------------------------------------------------

-- drop constraints, foreign keys first then PK
ALTER TABLE [config].[EntityDetail] DROP CONSTRAINT IF EXISTS [FK_EntityDetail_GridConfiguration_GridConfigurationId]
ALTER TABLE [config].[GeoSpatialMaps] DROP CONSTRAINT IF EXISTS [FK_GeoSpatialMaps_GridConfiguration_GridConfigurationId]
ALTER TABLE [config].[GridColumn] DROP CONSTRAINT IF EXISTS [FK_GridColumn_GridConfiguration_GridConfigurationId]
ALTER TABLE [app_generated].[SearchCore] DROP CONSTRAINT IF EXISTS [FK_SearchCore_GridConfiguration_GridConfigurationId]
ALTER TABLE [app_generated].[WatchlistConfiguration] DROP CONSTRAINT IF EXISTS [FK_WatchlistConfiguration_GridConfiguration_GridConfigurationId]
ALTER TABLE [app_generated].[WorkingFolderConfiguration] DROP CONSTRAINT IF EXISTS [FK_WorkingFolderConfiguration_GridConfiguration_GridConfigurationId]

ALTER TABLE [config].[GridConfiguration] DROP CONSTRAINT IF EXISTS [PK_GridConfiguration]


------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [config].[EntityDetail] 
------------------------------------------------
-- drop indexes 
DROP INDEX IF EXISTS [IX_EntityDetail_GridConfigurationId] ON [config].[EntityDetail]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIduuid] = [source].[uuid]
FROM [config].[EntityDetail] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[EntityDetail] DROP Column [GridConfigurationId]
EXEC sp_rename '[config].[EntityDetail].GridConfigurationIduuid', 'GridConfigurationId', 'COLUMN';


-- re-create indexes
CREATE INDEX [IX_EntityDetail_GridConfigurationId] ON [config].[EntityDetail]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [config].[GeoSpatialMaps] 
------------------------------------------------
-- drop indexes 
DROP INDEX IF EXISTS [IX_GeoSpatialMaps_GridConfigurationId] ON [config].[GeoSpatialMaps]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIduuid] = [source].[uuid]
FROM [config].[GeoSpatialMaps] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[GeoSpatialMaps] DROP Column [GridConfigurationId]
EXEC sp_rename '[config].[GeoSpatialMaps].GridConfigurationIduuid', 'GridConfigurationId', 'COLUMN';


-- re-create indexes
CREATE INDEX [IX_GeoSpatialMaps_GridConfigurationId] ON [config].[GeoSpatialMaps]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [config].[GridColumn] 
------------------------------------------------
-- drop indexes 
DROP INDEX IF EXISTS [IX_GridColumn_GridConfigurationId] ON [config].[GridColumn]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIduuid] = [source].[uuid]
FROM [config].[GridColumn] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[GridColumn] DROP Column [GridConfigurationId]
EXEC sp_rename '[config].[GridColumn].GridConfigurationIduuid', 'GridConfigurationId', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [config].[GridColumn] ALTER COLUMN [GridConfigurationId] uniqueidentifier NOT NULL

-- re-create indexes
CREATE INDEX [IX_GridColumn_GridConfigurationId] ON [config].[GridColumn]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [app_generated].[SearchCore] 
------------------------------------------------
-- drop indexes 
DROP INDEX IF EXISTS [IX_SearchCore_GridConfigurationId] ON [app_generated].[SearchCore]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIduuid] = [source].[uuid]
FROM [app_generated].[SearchCore] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [app_generated].[SearchCore] DROP Column [GridConfigurationId]
EXEC sp_rename '[app_generated].[SearchCore].GridConfigurationIduuid', 'GridConfigurationId', 'COLUMN';


-- re-create indexes
CREATE INDEX [IX_SearchCore_GridConfigurationId] ON [app_generated].[SearchCore]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [app_generated].[WatchlistConfiguration] 
------------------------------------------------
-- drop indexes 
DROP INDEX IF EXISTS [IX_WatchlistConfiguration_GridConfigurationId] ON [app_generated].[WatchlistConfiguration]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIduuid] = [source].[uuid]
FROM [app_generated].[WatchlistConfiguration] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [app_generated].[WatchlistConfiguration] DROP Column [GridConfigurationId]
EXEC sp_rename '[app_generated].[WatchlistConfiguration].GridConfigurationIduuid', 'GridConfigurationId', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [app_generated].[WatchlistConfiguration] ALTER COLUMN [GridConfigurationId] uniqueidentifier NOT NULL

-- re-create indexes
CREATE INDEX [IX_WatchlistConfiguration_GridConfigurationId] ON [app_generated].[WatchlistConfiguration]([GridConfigurationId])



------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[GridConfiguration]  and [app_generated].[WorkingFolderConfiguration] 
------------------------------------------------
-- drop indexes 
DROP INDEX IF EXISTS [IX_WorkingFolderConfiguration_GridConfigurationId] ON [app_generated].[WorkingFolderConfiguration]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[GridConfigurationIduuid] = [source].[uuid]
FROM [app_generated].[WorkingFolderConfiguration] [target] INNER JOIN [config].[GridConfiguration] [source] ON [source].[Id] = [target].[GridConfigurationId]

-- Drop old foreign key column and rename new one
ALTER TABLE [app_generated].[WorkingFolderConfiguration] DROP Column [GridConfigurationId]
EXEC sp_rename '[app_generated].[WorkingFolderConfiguration].GridConfigurationIduuid', 'GridConfigurationId', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [app_generated].[WorkingFolderConfiguration] ALTER COLUMN [GridConfigurationId] uniqueidentifier NOT NULL

-- re-create indexes
CREATE INDEX [IX_WorkingFolderConfiguration_GridConfigurationId] ON [app_generated].[WorkingFolderConfiguration]([GridConfigurationId])


-- Drop old primary key column and rename new one
ALTER TABLE [config].[GridConfiguration] DROP Column [Id]
EXEC sp_rename '[config].[GridConfiguration].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GridConfiguration] ADD CONSTRAINT [PK_GridConfiguration] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
ALTER TABLE [config].[EntityDetail] ADD CONSTRAINT [FK_EntityDetail_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [config].[EntityDetail] CHECK CONSTRAINT [FK_EntityDetail_GridConfiguration_GridConfigurationId];

ALTER TABLE [config].[GeoSpatialMaps] ADD CONSTRAINT [FK_GeoSpatialMaps_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [config].[GeoSpatialMaps] CHECK CONSTRAINT [FK_GeoSpatialMaps_GridConfiguration_GridConfigurationId];

ALTER TABLE [config].[GridColumn] ADD CONSTRAINT [FK_GridColumn_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [config].[GridColumn] CHECK CONSTRAINT [FK_GridColumn_GridConfiguration_GridConfigurationId];

ALTER TABLE [app_generated].[SearchCore] ADD CONSTRAINT [FK_SearchCore_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [app_generated].[SearchCore] CHECK CONSTRAINT [FK_SearchCore_GridConfiguration_GridConfigurationId];

ALTER TABLE [app_generated].[WatchlistConfiguration] ADD CONSTRAINT [FK_WatchlistConfiguration_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [app_generated].[WatchlistConfiguration] CHECK CONSTRAINT [FK_WatchlistConfiguration_GridConfiguration_GridConfigurationId];

ALTER TABLE [app_generated].[WorkingFolderConfiguration] ADD CONSTRAINT [FK_WorkingFolderConfiguration_GridConfiguration_GridConfigurationId] FOREIGN KEY ([GridConfigurationId]) REFERENCES [config].[GridConfiguration]([Id])
ALTER TABLE [app_generated].[WorkingFolderConfiguration] CHECK CONSTRAINT [FK_WorkingFolderConfiguration_GridConfiguration_GridConfigurationId];

