------------------------------------------------
-- MIGRATION FOR [config].[GroupRole]
------------------------------------------------

-- drop constraints, foreign keys first then PK

ALTER TABLE [config].[GroupRole] DROP CONSTRAINT IF EXISTS [PK_GroupRole]

-- Drop old primary key column and rename new one
ALTER TABLE [config].[GroupRole] DROP Column [Id]
EXEC sp_rename '[config].[GroupRole].uuid', 'Id', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[GroupRole] ADD CONSTRAINT [PK_GroupRole] PRIMARY KEY ([Id]);
-- Re-add foreign keys and check their validity
