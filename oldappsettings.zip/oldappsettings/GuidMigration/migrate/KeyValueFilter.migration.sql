------------------------------------------------
-- MIGRATION FOR [config].[KeyValueFilter]
------------------------------------------------

-- drop constraints, foreign keys first then PK
ALTER TABLE [config].[KeyValueFilterDetail] DROP CONSTRAINT IF EXISTS [FK_KeyValueFilterDetail_KeyValueFilter_KeyValueFilterID]

ALTER TABLE [config].[KeyValueFilter] DROP CONSTRAINT IF EXISTS [PK_KeyValueFilter]


------------------------------------------------
-- MODIFYING RELATIONSHIP BETWEEN [config].[KeyValueFilter]  and [config].[KeyValueFilterDetail] 
------------------------------------------------
-- drop indexes 
DROP INDEX IF EXISTS [IX_KeyValueFilterDetail_KeyValueFilterID] ON [config].[KeyValueFilterDetail]

-- Update dependant table FK values
UPDATE [target]
SET
    [target].[KeyValueFilterIDuuid] = [source].[uuid]
FROM [config].[KeyValueFilterDetail] [target] INNER JOIN [config].[KeyValueFilter] [source] ON [source].[Key] = [target].[KeyValueFilterID]

-- Drop old foreign key column and rename new one
ALTER TABLE [config].[KeyValueFilterDetail] DROP Column [KeyValueFilterID]
EXEC sp_rename '[config].[KeyValueFilterDetail].KeyValueFilterIDuuid', 'KeyValueFilterID', 'COLUMN';

-- FK was not nullable, put it back
ALTER TABLE [config].[KeyValueFilterDetail] ALTER COLUMN [KeyValueFilterID] uniqueidentifier NOT NULL

-- re-create indexes
CREATE INDEX [IX_KeyValueFilterDetail_KeyValueFilterID] ON [config].[KeyValueFilterDetail]([KeyValueFilterID])


-- Drop old primary key column and rename new one
ALTER TABLE [config].[KeyValueFilter] DROP Column [Key]
EXEC sp_rename '[config].[KeyValueFilter].uuid', 'Key', 'COLUMN';

-- Add primary key constraint back
ALTER TABLE [config].[KeyValueFilter] ADD CONSTRAINT [PK_KeyValueFilter] PRIMARY KEY ([Key]);
-- Re-add foreign keys and check their validity
ALTER TABLE [config].[KeyValueFilterDetail] ADD CONSTRAINT [FK_KeyValueFilterDetail_KeyValueFilter_KeyValueFilterID] FOREIGN KEY ([KeyValueFilterID]) REFERENCES [config].[KeyValueFilter]([Key])
ALTER TABLE [config].[KeyValueFilterDetail] CHECK CONSTRAINT [FK_KeyValueFilterDetail_KeyValueFilter_KeyValueFilterID];

