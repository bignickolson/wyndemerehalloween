WITH PK_Info AS (
    SELECT 
        t.TABLE_NAME AS name,
        t.TABLE_SCHEMA AS [schema],
        kcu.COLUMN_NAME AS pkColumn,
        tc.CONSTRAINT_NAME AS pkConstraint
    FROM INFORMATION_SCHEMA.TABLES t
    JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS tc
        ON t.TABLE_NAME = tc.TABLE_NAME AND t.TABLE_SCHEMA = tc.TABLE_SCHEMA
    JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE kcu
        ON tc.CONSTRAINT_NAME = kcu.CONSTRAINT_NAME
    WHERE tc.CONSTRAINT_TYPE = 'PRIMARY KEY'
        AND t.TABLE_NAME IN (
,'GroupRole'
,'MenuComponent'
,'MenuRole'
,'FeatureFlag'
,'EntityDetail'
,'EntityDetailItem'
,'GridConfiguration'
,'MiniProfileItemMapping'
,'SocialNetworkItemMapping'
,'GridColumn'
,'KeyValueFilter'
,'KeyValueFilterDetail'
,'GeoSpatialIcon'
,'GeoNode'
,'ScoreCard'
,'FEFilter'
,'CaseItemDetail'
,'ClaimDetail'		
) -- Replace with your list of table names
),
DependentTables AS (
    SELECT 
        fk.name AS fkConstraint,
        pk_table.name AS pkTable,
        fkcol.name AS fkColumn,
        dep_table.name AS depTable,
        dep_schema.name AS depSchema,
        ix.name AS indexName,
        CASE 
            WHEN fkcol.is_nullable = 1 THEN CAST(1 AS BIT)
            ELSE CAST(0 AS BIT)
        END AS isNullable -- New nullable flag
    FROM sys.foreign_keys fk
    JOIN sys.foreign_key_columns fkc
        ON fk.object_id = fkc.constraint_object_id
    JOIN sys.tables pk_table
        ON fk.referenced_object_id = pk_table.object_id
    JOIN sys.schemas pk_schema
        ON pk_table.schema_id = pk_schema.schema_id
    JOIN sys.columns fkcol
        ON fkc.parent_object_id = fkcol.object_id AND fkc.parent_column_id = fkcol.column_id
    JOIN sys.tables dep_table
        ON fk.parent_object_id = dep_table.object_id
    JOIN sys.schemas dep_schema
        ON dep_table.schema_id = dep_schema.schema_id
    LEFT JOIN sys.index_columns ic
        ON ic.column_id = fkc.parent_column_id AND ic.object_id = dep_table.object_id
    LEFT JOIN sys.indexes ix
        ON ix.object_id = ic.object_id AND ix.index_id = ic.index_id
),
JSON_Result AS (
    SELECT 
        pk.name,
        pk.[schema],
        pk.pkColumn,
        pk.pkConstraint,
        (
            SELECT 
                depTable AS name,
                depSchema AS [schema],
                fkColumn,
                fkConstraint,
                isNullable, -- Add isNullable property to the JSON output
                (
                    SELECT 
                        indexName AS name,
                        fkColumn AS columns
                    FROM DependentTables dt2
                    WHERE dt2.depTable = dt.depTable
                        AND dt2.depSchema = dt.depSchema
                        AND dt2.fkColumn = dt.fkColumn
                    FOR JSON PATH
                ) AS indexes
            FROM DependentTables dt
            WHERE dt.pkTable = pk.name
            FOR JSON PATH
        ) AS depTables
    FROM PK_Info pk
)
SELECT
    (
        SELECT 
            JSON_Result.*
        FROM JSON_Result
        FOR JSON PATH, ROOT('tables')
    ) AS json_output;
