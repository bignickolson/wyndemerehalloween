$FilePath = "F:\nolsona\FraudCaster_FraudDetect\Pondera.Data\SearchConfigurations\MiniProfileItemMappingConfiguration.cs"
$ChildFilePath = ""
$RegexPattern = "Id = (\d+),"


# Check if file exists
if (-not (Test-Path $FilePath)) {
    Write-Host "File not found: $FilePath"
    exit 1
}

# Read the content of the file
$fileContent = Get-Content -Path $FilePath -Raw
if ($ChildFilePath -ne "") {
    $childFileContent = Get-Content -Path $ChildFilePath -Raw
}

# Find all matches and loop through them individually
$regex = [regex]::new($RegexPattern)
$matches = $regex.Matches($fileContent)

foreach ($match in $matches) {
    $newGuid = [Guid]::NewGuid().ToString()

    $idValue = $match.Groups[1].Value

    #replace value in child files
    if ($ChildFilePath -ne "") {

        $secondPattern = "EntityDetailId = $idValue,"
        $childFileContent = $childFileContent.Replace($secondPattern, "EntityDetailId = Guid.Parse(`"$newGuid`"),")
    }
    # Replace the captured group with 'Guid.Parse("<new guid>")'
    $replacement = $match.Groups[0].Value.Replace($match.Groups[1].Value, "Guid.Parse(`"$newGuid`")")
    $fileContent = $fileContent.Replace($match.Value, $replacement)
}

# Save the updated content back to the file
Set-Content -Path $FilePath -Value $fileContent
if ($ChildFilePath -ne "") {

    Set-Content -Path $ChildFilePath -Value $childFileContent
}
Write-Host "File updated successfully!"
