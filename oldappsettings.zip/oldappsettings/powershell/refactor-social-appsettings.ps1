param (
	[Parameter(Mandatory = $true)]
    [string]$basePath = "C:\Path\To\Your\Directory"
)

# Recursively search for all appsettings.*.json files
$files = Get-ChildItem -Path $basePath -Filter "appsettings.*.json" -Recurse

foreach ($file in $files) {
    # Load the JSON content
    $jsonContent = Get-Content -Path $file.FullName -Raw | ConvertFrom-Json

    # Check if SocialNetworkConfig exists
    if ($jsonContent.SocialNetworkConfig) {
        # Update Url field and add new fields
        $jsonContent.SocialNetworkConfig.Url = "https://demo3.carpe.io/interfaces/"
        $jsonContent.SocialNetworkConfig.V2Endpoint = "subject_search_v02"
        $jsonContent.SocialNetworkConfig.V1Endpoint = "subject_search_json_v01"

        # Convert JSON back to formatted string and write to file
        $jsonContent | ConvertTo-Json -Depth 10 | Set-Content -Path $file.FullName -Force
        Write-Output "Updated SocialNetworkConfig in $($file.FullName)"
    } else {
        Write-Output "No SocialNetworkConfig found in $($file.FullName)"
    }
}
